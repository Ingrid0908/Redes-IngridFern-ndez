﻿## **2.5.1 Estructura del sistema telefónico**

Para telecomunicaciones se usan diversos medios de transmisión. En nuestros días, los circuitos locales consisten en pares trenzados. Entre las oficinas de conmutación se usan ampliamente cables coaxiales, microondas y, en especial, fibra óptica.

Existe preferencia por la transmisión digital porque en ésta no es necesario reproducir exactamente una forma de onda analógica después de que ha pasado por muchos amplificadores en una llamada larga. Es suficiente con distinguir correctamente un 0 de un 1. Su mantenimiento también es más económico y sencillo.

En síntesis, el sistema telefónico consiste en tres componentes principales:

1. Circuitos locales (cables de par trenzado que van hacia las casas y las empresas).

2. Troncales (fibra óptica digital que conecta a las oficinas de conmutación).

3. Oficinas de conmutación (donde las llamadas pasan de una troncal a otra).
  
## **2.5.3 El circuito local: módems, ADSL e inalámbrico**

El circuito local se conoce también como de “última milla” (la conexión hacia el cliente). Cuando una computadora desea enviar datos digitales sobre una línea analógica de acceso telefónico, es necesario convertir primero los datos a formato analógico para transmitirlos sobre el circuito local. Un dispositivo conocido como módem realiza esta conversión.
Los datos se convierten a formato digital en la oficina central de la compañía telefónica para transmitirlos sobre las troncales que abarcan largas distancias. Si en el otro extremo hay una computadora con un módem, es necesario realizar la conversión inversa (digital a analógico) para recorrer el circuito local en el destino.
La señalización analógica consiste en la variación del voltaje con el tiempo para representar un flujo de información. Las líneas de transmisión tienen tres problemas principales: atenuación, distorsión por retardo y ruido.
-   La atenuación es la pérdida de energía conforme la señal se propaga hacia su destino.
-   Los diferentes componentes de Fourier se propagan a diferente velocidad por el cable. Esta diferencia de velocidad ocasiona una distorsión de la señal que se recibe en el otro extremo.
    
-   El ruido es energía no deseada de fuentes distintas al transmisor.

#### Modems

La señalización de CA (corriente alterna) se utiliza para superar los problemas asociados a la señalización de CC, en especial en las líneas telefónicas. Se introduce un tono continuo en el rango de 1000 a 2000 Hz, llamado portadora de onda senoidal, cuya amplitud, frecuencia o fase se pueden modular para transmitir la información.

1.  En la modulación de amplitud se usan dos niveles diferentes de amplitud para representar 0 y 1, respectivamente.
    
2.  En la modulación de frecuencia, conocida también como modulación por desplazamiento de frecuencia, se usan dos (o más) tonos diferentes.
    
3.  En la forma más simple de la modulación de fase la onda portadora se desplaza de modo sistemático 0 o 180 grados a intervalos espaciados de manera uniforme.
    

Un módem es un dispositivo que acepta un flujo de bits en serie como entrada y que produce una portadora modulada mediante uno (o más) de estos métodos (o viceversa). El módem se conecta entre la computadora (digital) y el sistema telefónico (analógico).

El número de muestras por segundo se mide en baudios. Un símbolo se envía durante cada baudio. De esta manera, una línea de n baudios transmite n símbolos por segundo.

-   El ancho de banda de un medio es el rango de frecuencias que atraviesa al medio con atenuación mínima.
    
-   La tasa de baudios es la cantidad de muestras por segundo que se realizan. La tasa de baudios y la tasa de símbolos significan lo mismo.
    
-   La tasa de bits es la cantidad de información que se envía por el canal y es igual a la cantidad de símbolos por segundo por la cantidad de bits por símbolo.

A los diagramas que muestran las combinaciones permitidas de amplitud y fase, se les llama diagramas de constelación. Cada estándar de módem de alta velocidad tiene su propio diagrama de constelación y se puede comunicar solamente con otros módems que utilicen el mismo modelo.

Todos los módems modernos transmiten tráfico en ambas direcciones al mismo tiempo.

-   La conexión que permite el flujo de tráfico en ambas direcciones de manera simultánea se conoce como dúplex total.
    
-   La conexión que permite el tráfico en ambas direcciones, pero sólo en un sentido a la vez, se denomina semidúplex.
    
-   La conexión que permite el tráfico en una sola dirección se conoce como símplex.
    

#### Líneas digitales de suscriptor
La razón por la cual los módems son tan lentos es que los teléfonos fueron creados para transportar la voz humana y todo el sistema se ha optimizado cuidadosamente con este propósito. Los datos siempre han sido un aspecto secundario.

El truco para que xDSL funcione es que cuando un cliente se suscribe al servicio, la línea de entrada se conecta a un tipo distinto de conmutador, que no cuenta con el filtro, gracias a lo cual toda la capacidad del circuito local queda disponible.

Todos los servicios xDSL se diseñaron para que cumplieran algunos objetivos.

-   Primero, los servicios deben funcionar sobre los circuitos locales existentes de par trenzado, categoría 3.
    
-   Segundo, no deben afectar las máquinas de fax ni los teléfonos existentes de los clientes.
    
-   Tercero, deben superar por mucho los 56 kbps.
    
-   Cuarto, siempre deben funcionar, con sólo una tarifa mensual, no por minuto.
    

AT&T hizo la oferta inicial de ADSL, el cual funcionaba dividiendo el espectro disponible en el circuito local, de alrededor de 1.1 MHz, en tres bandas de frecuencia: POTS (Servicio Telefónico Convencional), canal ascendente (del usuario a la oficina central) y canal descendente (de la oficina central al usuario).

El enfoque alternativo, llamado DMT (MultiTono Discreto), lo que hace es dividir el espectro disponible de 1.1 MHz en el circuito local en 256 canales independientes de 4312.5 Hz cada uno. El canal 0 se utiliza para el POTS. Los canales 1-5 no se emplean, con el propósito de evitar que las señales de voz y de datos interfieran entre sí. De los 250 canales restantes, uno se utiliza para control del flujo ascendente y uno para control del flujo descendente. El resto está disponible para datos del usuario.

NID (Dispositivo de Interfaz de Red) es una pequeña caja de plástico que delimita el fin de la propiedad de la compañía telefónica y el inicio de la propiedad del cliente.

Cerca del NID (o en ocasiones en combinación con él) hay un divisor, un filtro analógico que separa la banda de 0-4000 Hz utilizada por la voz (POTS) de los datos. La señal POTS se enruta hacia el teléfono o máquina de fax existente, y la señal de datos se enruta a un módem.

  

#### Circuitos locales inalámbricos

Muchas CLECs(LEC Competitiva) han encontrado una alternativa de bajo costo en lugar del tradicional circuito local con cable de par trenzado: el WLL (Circuito Local Inalámbrico). Se usaron las frecuencias de la televisión educativa ya que no se popularizó para los circuitos locales inalámbricos en un servicio denominado MMDS (Servicio de Distribución Multipunto y Multicanal). El MMDS se puede considerar como una MAN (red de área metropolitana), al igual que su similar LMDS.

La gran ventaja de este servicio es que la tecnología está bien desarrollada y que el equipo se consigue con facilidad. La desventaja consiste en que el ancho de banda total disponible es modesto y deben compartirlo muchos usuarios de una enorme área geográfica.

  

## **2.5.4 Troncales y multiplexión**

Cuesta prácticamente lo mismo instalar y mantener una troncal de ancho de banda alto que una de ancho de banda bajo entre dos oficinas de conmutación. En consecuencia, las compañías telefónicas han desarrollado esquemas complejos para multiplexar muchas conversaciones en una sola troncal física. Estos esquemas de multiplexión se pueden dividir en dos categorías principales:
FDM (Multiplexión por División de Frecuencia): el espectro de frecuencia se divide en bandas de frecuencia, y cada usuario posee exclusivamente alguna banda
TDM (Multiplexión por División de Tiempo): los usuarios esperan su turno (en round-robin), y cada uno obtiene en forma periódica toda la banda durante un breve lapso de tiempo.

#### Multiplexión por división de frecuencia

Los filtros limitan el ancho de banda utilizable a cerca de 3000 Hz por canal de calidad de voz. Cuando se multiplexan muchos canales juntos, se asignan 4000 Hz a cada canal para mantenerlos bien separados.

Un estándar muy difundido es el de 12 canales de voz a 4000 Hz multiplexados dentro de la banda de 60 a 108 kHz. Esta unidad se llama grupo. Se pueden multiplexar cinco grupos (60 canales de voz) para formar un supergrupo. La siguiente unidad es el grupo maestro, que se compone de cinco o 10 supergrupos

#### Multiplexión por división de longitud de onda

En realidad, aquí nada es nuevo. Se trata simplemente de multiplexión por división de frecuencia a frecuencias muy altas. Siempre y cuando cada canal tenga su propio rango de frecuencia (es decir, longitud de onda), y todos los intervalos estén separados, se pueden multiplexar juntos en la fibra de largo alcance. La única diferencia con respecto a la FDM eléctrica es que un sistema óptico que usa una rejilla de difracción es totalmente pasivo y, por ello, muy confiable.

#### Multiplexión por división de tiempo

La PCM (Modulación por Codificación de Impulsos) es el corazón del sistema telefónico moderno. En consecuencia, virtualmente todos los intervalos de tiempo dentro del sistema telefónico son múltiplos de 125 μseg. La portadora T1 consiste en 24 canales de voz que se multiplexan juntos.

La multiplexión por división de tiempo permite que se multiplexen varias portadoras T1 en portadoras de orden más alto. Cuando se utiliza un sistema T1 exclusivamente para datos, sólo 23 de los canales llevan datos. El vigésimo cuarto lleva un patrón especial de sincronización que permite la recuperación rápida en caso de que la trama pierda sincronía.

En la señalización por canal común, el bit extra adopta los valores 10101010... en las tramas nones y contiene información de señalización para todos los canales de las tramas pares. En la otra variante, la señalización por canal asociado, cada canal tiene su propio subcanal privado de señalización.

Un método llamado modulación diferencial por codificación de impulsos consiste en transmitir no la amplitud digitalizada sino la diferencia entre su valor actual y el previo.

#### SONET/SDH

En 1989 se produjo un estándar SONET y un conjunto de recomendaciones paralelas del CCITT (G.707, G.708 y G.709). A las recomendaciones del CCITT se les llama SDH (Jerarquía Digital Síncrona) pero difieren de SONET sólo en detalles menores. El diseño de SONET tuvo cuatro objetivos principales:

-   Tenía que hacer posible la interconexión de diferentes operadores telefónicos.
    
-   Se necesitaban medidas para unificar los sistemas digitales estadounidense, europeo y japonés.
    
-   Tenía que proporcionar un mecanismo para multiplexar varios canales digitales.
    
-   Tenía que proporcionar apoyo para las operaciones, la administración y el mantenimiento (OAM).

SONET es un sistema síncrono, controlado por un reloj maestro con una precisión de alrededor de 1 parte en 109.

## **2.7 TELEVISIÓN POR CABLE**

### **2.7.1 Televisión por antena comunal**

El sistema consistió inicialmente en una antena grande en la cima de una colina para captar la señal de televisión, un amplificador, llamado amplificador head end, para reforzarla y un cable coaxial para enviarla a las casas de las personas. En 1974, inició un nuevo canal, Home Box Office, con contenido nuevo (películas) y que se distribuía sólo por cable.

Este desarrollo dio origen a dos cambios en la industria. Primero, las grandes compañías comenzaron a comprar sistemas de cable existentes e instalar nuevo cable para adquirir más suscriptores. Segundo, surgió la necesidad de conectar múltiples sistemas, por lo general en ciudades distantes, para distribuir los nuevos canales por cable.

### **2.7.2 Internet a través de cable**

Un sistema con fibra para distancias considerables y cable coaxial para las casas se conoce como sistema HFC (Red Híbrida de Fibra Óptica y Cable Coaxial). Los convertidores electroópticos que interactúan entre las partes óptica y eléctrica del sistema se llaman nodos de fibra.

### **2.7.3 Asignación de espectro**

Deshacerse de todos los canales de TV y utilizar la infraestructura de cable tan sólo para el acceso a Internet tal vez generaría una cantidad considerable de clientes iracundos, por lo que las compañías de cable dudan en hacer esto.

La solución elegida fue introducir canales ascendentes en la banda de 5–42 MHz (un poco más arriba en Europa) y utilizar las frecuencias en el extremo superior para el flujo descendente.

Las compañías telefónicas por lo general ofrecen un servicio DSL asimétrico, aunque no tienen ninguna razón técnica para hacerlo.

### **2.7.4 Módems de cable**

El acceso a Internet requiere un módem de cable, un dispositivo que tiene dos interfaces: una en la computadora y la otra en la red de cable.

En consecuencia, los operadores de cable más grandes se unieron a una compañía llamada CableLabs para producir un módem de cable estándar y probar la compatibilidad de productos. Este estándar, llamado DOCSIS (Especificación de Interfaz para Servicio de Datos por Cable)

Los módems de cable establecen una conexión cuando se encienden y la mantienen todo el tiempo que tengan energía, debido a que los operadores de cable no cobran por el tiempo de conexión.

### **2.7.5 ADSL en comparación con el cable**

Los dos utilizan la fibra óptica en la red dorsal, pero difieren en el extremo. El cable utiliza cable coaxial; ADSL, cable de par trenzado. Los proveedores de ADSL indican específicamente el ancho de banda, por otro lado, los proveedores de cable no dan ninguna indicación pues la capacidad efectiva depende de cuántas personas estén actualmente activas en el segmento de cable del usuario.

Conforme un sistema ADSL adquiere usuarios, este incremento tiene muy poco efecto en los usuarios existentes, debido a que cada usuario tiene una conexión dedicada. Con el cable, conforme más personas se suscriban al servicio de Internet, el rendimiento de los usuarios existentes disminuirá.

La disponibilidad es un tema en el que ADSL y el cable difieren. Todas las personas tienen teléfono, pero no todos los usuarios están lo suficientemente cerca de su oficina central local para obtener ADSL.

Debido a que es un medio de punto a punto, ADSL es inherentemente más seguro que el cable.
