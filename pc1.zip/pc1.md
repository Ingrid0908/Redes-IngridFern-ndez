﻿Ingrid Fernández Arce
Prueba corta #1
***

1. Explique de forma concisa, ¿Porqué la transmisión de ondas de baja frecuencia no es práctica en medios inalámbricos?

No es práctica ya que para realizar transmisiones en frecuencias bajas se necesitan antenas gigantes y se tienen muchas restricciones regulatorias. Además que se encuentran muy saturadas.

  

2. Ante una crisis como conflicto bélico o un desastre natural, que daña o afecta los canales de comunicación o infraestructura de un país, ¿Qué tipo de transmisión recomendaría a ese país para mantener comunicación con el resto del mundo? Explique.

 
Recomendaría una transmisión satelital ya que dichas transmisiones no son rastreables y no se pueden controlar cómo se podría hacer en un conflicto bélico. Los canales de comunicación o infraestructura no podrían ser dañados o afectados por los desastres naturales ya que la mayoría de infraestructura necesaria se encuentra en la órbita de la tierra.

  

3. ¿En que consiste el concepto ancho de banda en telecomunicaciones? Explique detalladamente

Es el rango de frecuencias que se transmiten en el marco de una comunicación en un determinado tiempo, es una propiedad física del medio de transmisión generalmente depende de la construcción, grosor y longitud del medio. Se le puede poner un filtro para limitar el ancho de banda de cada cliente lo que mejora la eficiencia.

  

4. ¿Por cuáles motivos se presenta la atenuación en una señal? Explicar tanto en medios cableados como no cableados.

Medios cableados: Se puede tener atenuación por propiedades físicas del vidrio, por la longitud de la onda de luz, por pérdida de energía, por la distancia que la señal deba recorrer (entre más distancia la señal perderá más potencia) y por el ruido del ambiente.

Medios no cableados: Se puede tener atenuación por distorsión por retardo, por ruido por ejemplo térmico, interferencia electromagnética o por distancia.
